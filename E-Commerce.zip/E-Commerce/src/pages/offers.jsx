import React from 'react'

const offers = () => {
  return (
    <div>
        
    </div>
  )
}

export default offers